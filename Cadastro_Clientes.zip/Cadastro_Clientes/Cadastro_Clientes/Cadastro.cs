﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Cadastro_Clientes
{
    public partial class Cadastro : Form
    {
        public Cadastro()
        {
            InitializeComponent();
            CarregaGrid();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (TxtNome.Text=="")
            {
                MessageBox.Show("O Campo Nome não pode ser em branco!", "Atenção");
                TxtNome.Focus();
                TxtNome.BackColor = Color.Red;
                return;
            }


            if (!MaskData.MaskCompleted)
            {
                MessageBox.Show("O Campo Data Nascimento não pode ser em branco!", "Atenção");
                MaskData.Focus();
                MaskData.BackColor = Color.Red;
                return;
            }


            if (!ValidaCPF.IsCpf(MaskCpf.Text))
            {
                MessageBox.Show("CPF Inválido!", "Atenção");
                MaskCpf.Focus();
                MaskCpf.BackColor = Color.Red;
                return;
            }

            if (!MaskCel.MaskCompleted)
            {
                MessageBox.Show("O Campo Celular não pode ser em branco!", "Atenção");
                MaskCel.Focus();
                MaskCel.BackColor = Color.Red;
                return;
            }

            if (txtEmail.Text == "")
            {
                MessageBox.Show("O Campo E-mail não pode ser em branco!", "Atenção");
                txtEmail.Focus();
                txtEmail.BackColor = Color.Red;
                return;
            }

            if (TxtEndereco.Text == "")
            {
                MessageBox.Show("O Campo Endereço não pode ser em branco!", "Atenção");
                TxtEndereco.Focus();
                TxtEndereco.BackColor = Color.Red;
                return;
            }

            if (label11.Text == "")
            {

                String scon = @"Server =DESKTOP-6VOQCAI\SQLEXPRESS;Database = CLIENTES; Integrated Security = SSPI;";
                SqlConnection con = new SqlConnection(scon);
                con.Open();

                string Incluir = @"INSERT INTO [dbo].[Clientes]
           ([NOME]
           ,[NASCIMENTO]
           ,[CPF]
           ,[CELULAR]
           ,[EMAIL]
           ,[ENDERECO]
           ,[OBSERVACAO])
     VALUES ('" + TxtNome.Text + "', '" + Convert.ToDateTime(MaskData.Text).ToString("yyyy-MM-dd") + "','" + MaskCpf.Text.Replace(".", "").Replace("-", "") + "','" + MaskCel.Text.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", "") + "','" + txtEmail.Text + "','" + TxtEndereco.Text + "','" + txtobs.Text + "');";
                SqlCommand cmd = new SqlCommand(Incluir, con);
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Dados Incluidos!", "Informação");

                TxtNome.Text = "";
                MaskData.Text = "";
                MaskCel.Text = "";
                MaskCpf.Text = "";
                TxtEndereco.Text = "";
                txtobs.Text = "";
                txtEmail.Text = "";


                TxtNome.BackColor = Color.White;
                MaskData.BackColor = Color.White;
                MaskCel.BackColor = Color.White;
                MaskCpf.BackColor = Color.White;
                TxtEndereco.BackColor = Color.White;
                txtEmail.BackColor = Color.White;

                CarregaGrid();
            }

            else

            {
                String scon = @"Server =DESKTOP-6VOQCAI\SQLEXPRESS;Database = CLIENTES; Integrated Security = SSPI;";
                SqlConnection con = new SqlConnection(scon);
                con.Open();

                string Incluir = @"UPDATE [dbo].[Clientes] SET [NOME] = '" + TxtNome.Text + "',[NASCIMENTO] = '" + Convert.ToDateTime(MaskData.Text).ToString("yyyy-MM-dd") + "',[CPF] = '" + MaskCpf.Text.Replace(".", "").Replace("-", "") + "',[CELULAR] ='" + MaskCel.Text.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", "") + "',[EMAIL] = '" + txtEmail.Text  + "',[ENDERECO] = '" + TxtEndereco.Text + "',[OBSERVACAO] ='" + txtobs.Text + "' WHERE ID='" + label11.Text + "'";
                SqlCommand cmd = new SqlCommand(Incluir, con);
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Dados Alterados!", "Informação");

                TxtNome.Text = "";
                MaskData.Text = "";
                MaskCel.Text = "";
                MaskCpf.Text = "";
                TxtEndereco.Text = "";
                txtobs.Text = "";
                txtEmail.Text = "";
                label11.Text = "";
                CarregaGrid();
            }
        }

        private void CarregaGrid()
        {
            String scon = @"Server =DESKTOP-6VOQCAI\SQLEXPRESS;Database = CLIENTES; Integrated Security = SSPI;";
            SqlConnection con = new SqlConnection(scon);
            con.Open();

            String scom = "Select top 10 * from Clientes";
            SqlDataAdapter da = new SqlDataAdapter(scom, con);

            DataTable clientes = new DataTable();
            da.Fill(clientes);
            dataGridView1.DataSource = clientes;
        }

        private void verificacampos(TextBox textBox, ErrorProvider errorProvider)
        {
            if (TxtNome.Text == "")
            {

                errorProvider.SetError(TxtNome, "Preenchimento Obrigatório");
            
            }
        }

        private void consultarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Consulta Consulta = new Consulta();
            //Consulta.ShowDialog();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            CarregagridNome();
        }

        private void CarregagridNome()
        {
            String scon = @"Server =DESKTOP-6VOQCAI\SQLEXPRESS;Database = CLIENTES; Integrated Security = SSPI;";
            SqlConnection con = new SqlConnection(scon);
            con.Open();

            String scom = "Select top 10 * from Clientes where Nome like '%" + txtpesqNome.Text + "%'";
            SqlDataAdapter da = new SqlDataAdapter(scom, con);

            DataTable clientes = new DataTable();
            da.Fill(clientes);
            dataGridView1.DataSource = clientes;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            CarregagridEmail();

        }

        private void CarregagridEmail()
        {
            String scon = @"Server =DESKTOP-6VOQCAI\SQLEXPRESS;Database = CLIENTES; Integrated Security = SSPI;";
            SqlConnection con = new SqlConnection(scon);
            con.Open();

            String scom = "Select top 10 * from Clientes where email like '%" + txtpesquisaemail.Text + "%'";
            SqlDataAdapter da = new SqlDataAdapter(scom, con);

            DataTable clientes = new DataTable();
            da.Fill(clientes);
            dataGridView1.DataSource = clientes;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var Row = dataGridView1.CurrentRow;

           label11.Text = Row.Cells[0].Value.ToString();

            consultarEdicao();
        }

        private void consultarEdicao()
        {
            String scon = @"Server =DESKTOP-6VOQCAI\SQLEXPRESS;Database = CLIENTES; Integrated Security = SSPI;";
            SqlConnection con = new SqlConnection(scon);
            con.Open();

            SqlCommand cmd = new SqlCommand();
            SqlDataReader reader;

            cmd.CommandText = @"Select * from Clientes where ID='" + label11.Text + "'";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;

           
            reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                TxtNome.Text = reader["Nome"].ToString();
                MaskData.Text = reader["nascimento"].ToString();
                MaskCpf.Text = reader["cpf"].ToString();
                MaskCel.Text = reader["celular"].ToString();
                txtEmail.Text = reader["email"].ToString();
                TxtEndereco.Text = reader["endereco"].ToString();
                txtobs.Text = reader["observacao"].ToString();
            }
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja excluir o registro?", "Exclusão", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                String scon = @"Server =DESKTOP-6VOQCAI\SQLEXPRESS;Database = CLIENTES; Integrated Security = SSPI;";
                SqlConnection con = new SqlConnection(scon);
                con.Open();

                string Incluir = @"DELETE FROM [dbo].[Clientes] where id='" + label11.Text + "' ";
                SqlCommand cmd = new SqlCommand(Incluir, con);
                cmd.ExecuteNonQuery();
                con.Close();

                TxtNome.Text = "";
                MaskData.Text = "";
                MaskCel.Text = "";
                MaskCpf.Text = "";
                TxtEndereco.Text = "";
                txtobs.Text = "";
                txtEmail.Text = "";
                label11.Text = "";
                CarregaGrid();

                MessageBox.Show("Registro excluído com sucesso", "Sucesso");
            }

            
        }

        /// <summary>
        /// Realiza a validação do CPF
        /// </summary>
        public static class ValidaCPF
        {
            public static bool IsCpf(string cpf)
            {
                int[] multiplicador1 = new int[9] { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
                int[] multiplicador2 = new int[10] { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };
                string tempCpf;
                string digito;
                int soma;
                int resto;
                cpf = cpf.Trim();
                cpf = cpf.Replace(".", "").Replace("-", "");
                if (cpf.Length != 11)
                    return false;
                tempCpf = cpf.Substring(0, 9);
                soma = 0;

                for (int i = 0; i < 9; i++)
                    soma += int.Parse(tempCpf[i].ToString()) * multiplicador1[i];
                resto = soma % 11;
                if (resto < 2)
                    resto = 0;
                else
                    resto = 11 - resto;
                digito = resto.ToString();
                tempCpf = tempCpf + digito;
                soma = 0;
                for (int i = 0; i < 10; i++)
                    soma += int.Parse(tempCpf[i].ToString()) * multiplicador2[i];
                resto = soma % 11;
                if (resto < 2)
                    resto = 0;
                else
                    resto = 11 - resto;
                digito = digito + resto.ToString();
                return cpf.EndsWith(digito);
            }
        }

        private void MaskCpf_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            if (!ValidaCPF.IsCpf(MaskCpf.Text))
            {
                MessageBox.Show("CPF Inválido!", "Atenção");
            }
        }

    }
}
